from setuptools import setup

package_name = 'helium_arduino_interface'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools', 'pyserial'],
    zip_safe=True,
    maintainer='heliumdrone',
    maintainer_email='heliumdrone@example.com',
    description='Arduino serial bridge for servo and IMU interface',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'serial_bridge = helium_arduino_interface.serial_bridge:main',
            'drive_teleop = helium_arduino_interface.drive_teleop:main',
            'camera_teleop = helium_arduino_interface.camera_teleop:main',
        ],
    },
)
