import math
import threading
import serial

import rclpy
from rclpy.node import Node

from std_msgs.msg import Int32MultiArray
from sensor_msgs.msg import Imu


class ArduinoSerialBridge(Node):
    def __init__(self):
        super().__init__('arduino_serial_bridge')

        self.declare_parameter('port', '/dev/ttyACM0')
        self.declare_parameter('baud', 115200)

        port = self.get_parameter('port').get_parameter_value().string_value
        baud = self.get_parameter('baud').get_parameter_value().integer_value

        self.get_logger().info(f'Opening serial port {port} at {baud} baud')

        self.ser = serial.Serial(port, baudrate=baud, timeout=0.05)

        self.drive_sub = self.create_subscription(
            Int32MultiArray,
            '/servo_drive_cmd',
            self.drive_callback,
            10
        )

        self.camera_sub = self.create_subscription(
            Int32MultiArray,
            '/servo_camera_cmd',
            self.camera_callback,
            10
        )

        self.imu_pub = self.create_publisher(Imu, '/arduino_imu', 10)

        self.reader_thread = threading.Thread(target=self.read_loop, daemon=True)
        self.reader_thread.start()

        self.get_logger().info('Arduino serial bridge started.')

    def send_line(self, line: str):
        try:
            self.ser.write((line + '\n').encode('utf-8'))
            self.ser.flush()
        except Exception as e:
            self.get_logger().error(f'Serial write failed: {e}')

    def drive_callback(self, msg: Int32MultiArray):
        if len(msg.data) < 2:
            self.get_logger().warn('Drive command needs [right_deg, left_deg]')
            return

        right_deg = int(msg.data[0])
        left_deg = int(msg.data[1])

        cmd = f'DRV,{right_deg},{left_deg}'
        self.send_line(cmd)

    def camera_callback(self, msg: Int32MultiArray):
        if len(msg.data) < 2:
            self.get_logger().warn('Camera command needs [rot_deg, pitch_deg]')
            return

        rot_deg = int(msg.data[0])
        pitch_deg = int(msg.data[1])

        cmd = f'CAM,{rot_deg},{pitch_deg}'
        self.send_line(cmd)

    def read_loop(self):
        while rclpy.ok():
            try:
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                if not line:
                    continue

                if line.startswith('IMU,'):
                    self.handle_imu_line(line)
                else:
                    self.get_logger().info(f'Arduino: {line}')

            except Exception as e:
                self.get_logger().error(f'Serial read failed: {e}')

    def handle_imu_line(self, line: str):
        parts = line.split(',')
        if len(parts) != 13:
            self.get_logger().warn(f'Bad IMU line: {line}')
            return

        try:
            (
                _tag,
                ax, ay, az,
                gx, gy, gz,
                mx, my, mz,
                roll, pitch, yaw
            ) = parts

            ax = float(ax)
            ay = float(ay)
            az = float(az)

            gx = float(gx)
            gy = float(gy)
            gz = float(gz)

            mx = float(mx)
            my = float(my)
            mz = float(mz)

            roll = float(roll)
            pitch = float(pitch)
            yaw = float(yaw)

            msg = Imu()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'arduino_imu_link'

            # accel currently in g, optionally convert to m/s^2
            msg.linear_acceleration.x = ax * 9.80665
            msg.linear_acceleration.y = ay * 9.80665
            msg.linear_acceleration.z = az * 9.80665

            # gyro is in deg/s, convert to rad/s for ROS Imu message
            msg.angular_velocity.x = gx * math.pi / 180.0
            msg.angular_velocity.y = gy * math.pi / 180.0
            msg.angular_velocity.z = gz * math.pi / 180.0

            # Orientation is not filled yet as quaternion
            msg.orientation_covariance[0] = -1.0

            self.imu_pub.publish(msg)

            self.get_logger().debug(
                f'RPY deg: roll={roll:.2f}, pitch={pitch:.2f}, yaw={yaw:.2f}'
            )

        except Exception as e:
            self.get_logger().warn(f'Failed to parse IMU line "{line}": {e}')


def main(args=None):
    rclpy.init(args=args)
    node = ArduinoSerialBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if hasattr(node, 'ser') and node.ser.is_open:
            node.ser.close()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
