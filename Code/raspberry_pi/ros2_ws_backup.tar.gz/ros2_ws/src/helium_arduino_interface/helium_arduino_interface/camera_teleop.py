import sys
import termios
import tty

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32MultiArray


def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch


class CameraTeleop(Node):
    def __init__(self):
        super().__init__('camera_teleop')
        self.pub = self.create_publisher(Int32MultiArray, '/servo_camera_cmd', 10)

        self.rot = 90
        self.pitch = 45
        self.step_deg = 2

        self.get_logger().info('Camera teleop ready.')
        self.get_logger().info('j/l rotate left/right, i/k pitch up/down, r reset, q quit')

    def clamp(self, val, lo, hi):
        return max(lo, min(hi, val))

    def publish_camera(self):
        msg = Int32MultiArray()
        msg.data = [self.rot, self.pitch]
        self.pub.publish(msg)
        self.get_logger().info(f'Sent camera command: rot={self.rot}, pitch={self.pitch}')

    def handle_key(self, key):
        if key == 'j':
            self.rot -= self.step_deg
        elif key == 'l':
            self.rot += self.step_deg
        elif key == 'i':
            self.pitch += self.step_deg
        elif key == 'k':
            self.pitch -= self.step_deg
        elif key == 'r':
            self.rot = 90
            self.pitch = 45
        else:
            return

        self.rot = self.clamp(self.rot, 0, 180)
        self.pitch = self.clamp(self.pitch, 0, 90)
        self.publish_camera()


def main(args=None):
    rclpy.init(args=args)
    node = CameraTeleop()

    try:
        node.publish_camera()
        while rclpy.ok():
            key = get_key()
            if key == 'q':
                break
            node.handle_key(key)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
