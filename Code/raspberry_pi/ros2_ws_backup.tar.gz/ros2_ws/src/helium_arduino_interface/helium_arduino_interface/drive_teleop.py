import sys
import termios
import tty

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32MultiArray


def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch


class DriveTeleop(Node):
    def __init__(self):
        super().__init__('drive_teleop')
        self.pub = self.create_publisher(Int32MultiArray, '/servo_drive_cmd', 10)

        self.commands = {
            'w': (45, 135),   # forward
            's': (135, 45),   # backward
            'a': (45, 45),    # left
            'd': (135, 135),  # right
            'x': (90, 90),    # neutral
            'u': (0, 180),    # up
            'j': (90, 90),    # down
        }

        self.get_logger().info('Drive teleop ready.')
        self.get_logger().info('w=forward s=backward a=left d=right x=neutral u=up j=down q=quit')

    def send_cmd(self, right_deg, left_deg):
        msg = Int32MultiArray()
        msg.data = [right_deg, left_deg]
        self.pub.publish(msg)
        self.get_logger().info(f'Sent drive command: right={right_deg}, left={left_deg}')


def main(args=None):
    rclpy.init(args=args)
    node = DriveTeleop()

    try:
        while rclpy.ok():
            key = get_key()
            if key == 'q':
                break
            if key in node.commands:
                right_deg, left_deg = node.commands[key]
                node.send_cmd(right_deg, left_deg)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
