from setuptools import find_packages, setup

package_name = 'helium_mav_control'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools', 'pymavlink'],
    zip_safe=True,
    maintainer='heliumdrone',
    maintainer_email='you@example.com',
    description='ROS 2 MAVLink motor controller for Pixhawk over ttyAMA0',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'mav_motor_controller = helium_mav_control.mav_motor_controller:main',
        ],
    },
)
