#!/usr/bin/env python3

import time

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from pymavlink import mavutil


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


class MavMotorController(Node):
    def __init__(self) -> None:
        super().__init__('mav_motor_controller')

        self.declare_parameter('device', '/dev/ttyAMA0')
        self.declare_parameter('baud', 57600)

        # Safe idle throttle for arming
        self.declare_parameter('idle_throttle', 1000)

        # Minimum throttle that actually starts your motors spinning
        self.declare_parameter('spin_throttle_start', 1200)

        # Max throttle to use from ROS commands
        self.declare_parameter('max_throttle', 1500)

        self.declare_parameter('neutral_yaw', 1500)
        self.declare_parameter('max_yaw_delta', 300)
        self.declare_parameter('publish_hz', 10.0)

        # Safer default: do not auto-arm until you confirm neutral startup works
        self.declare_parameter('arm_on_start', False)
        self.declare_parameter('disarm_on_shutdown', True)
        self.declare_parameter('telemetry_hz', 5.0)

        self.device = self.get_parameter('device').get_parameter_value().string_value
        self.baud = self.get_parameter('baud').get_parameter_value().integer_value
        self.idle_throttle = self.get_parameter('idle_throttle').get_parameter_value().integer_value
        self.spin_throttle_start = self.get_parameter('spin_throttle_start').get_parameter_value().integer_value
        self.max_throttle = self.get_parameter('max_throttle').get_parameter_value().integer_value
        self.neutral_yaw = self.get_parameter('neutral_yaw').get_parameter_value().integer_value
        self.max_yaw_delta = self.get_parameter('max_yaw_delta').get_parameter_value().integer_value
        self.publish_hz = self.get_parameter('publish_hz').get_parameter_value().double_value
        self.arm_on_start = self.get_parameter('arm_on_start').get_parameter_value().bool_value
        self.disarm_on_shutdown = self.get_parameter('disarm_on_shutdown').get_parameter_value().bool_value
        self.telemetry_hz = self.get_parameter('telemetry_hz').get_parameter_value().double_value

        self.current_linear_x = 0.0
        self.current_angular_z = 0.0

        self.sent_throttle_pwm = None
        self.sent_yaw_pwm = None
        self.cleaned_up = False

        self.last_armed_state = None
        self.last_mode = None

        self.get_logger().info(
            f'Connecting to Pixhawk on {self.device} at {self.baud} baud...'
        )
        self.master = mavutil.mavlink_connection(self.device, baud=self.baud)
        self.master.wait_heartbeat()
        self.get_logger().info(
            f'Connected to system={self.master.target_system} component={self.master.target_component}'
        )

        self.subscription = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_vel_callback,
            10,
        )

        override_timer_period = 1.0 / self.publish_hz
        self.override_timer = self.create_timer(override_timer_period, self.send_override)

        telemetry_timer_period = 1.0 / self.telemetry_hz
        self.telemetry_timer = self.create_timer(telemetry_timer_period, self.poll_telemetry)

        # Force safe neutral override immediately on startup
        self.send_neutral_override()
        time.sleep(1.0)
        self.send_neutral_override()
        time.sleep(1.0)

        if self.arm_on_start:
            self.arm_vehicle()

        self.get_logger().info('mav_motor_controller node started. Listening on /cmd_vel')

    def cmd_vel_callback(self, msg: Twist) -> None:
        self.current_linear_x = clamp(msg.linear.x, -1.0, 1.0)
        self.current_angular_z = clamp(msg.angular.z, -1.0, 1.0)

        self.get_logger().info(
            f'Received /cmd_vel: linear.x={self.current_linear_x:.2f}, '
            f'angular.z={self.current_angular_z:.2f}'
        )

    def send_neutral_override(self) -> None:
        self.master.mav.rc_channels_override_send(
            self.master.target_system,
            self.master.target_component,
            65535,              # ch1
            65535,              # ch2
            self.idle_throttle, # ch3 throttle low for safe arming
            self.neutral_yaw,   # ch4 neutral yaw
            65535,              # ch5
            65535,              # ch6
            65535,              # ch7
            65535               # ch8
        )
        self.get_logger().info(
            f'Sent neutral RC override: ch3={self.idle_throttle}, ch4={self.neutral_yaw}'
        )

    def arm_vehicle(self) -> None:
        self.get_logger().warn('Sending arm command to vehicle...')
        self.send_neutral_override()
        time.sleep(1.0)

        self.master.arducopter_arm()

        start_time = time.time()
        timeout_s = 5.0

        while time.time() - start_time < timeout_s:
            msg = self.master.recv_match(blocking=True, timeout=0.5)
            if msg is not None:
                self._handle_message(msg)

            if self.master.motors_armed():
                self.get_logger().warn('Pixhawk reports: ARMED')
                return

        self.get_logger().error('Arm command was sent, but Pixhawk did not report ARMED within timeout.')

    def disarm_vehicle(self) -> None:
        self.get_logger().warn('Sending disarm command to vehicle...')
        self.master.arducopter_disarm()

        start_time = time.time()
        timeout_s = 5.0

        while time.time() - start_time < timeout_s:
            msg = self.master.recv_match(blocking=True, timeout=0.5)
            if msg is not None:
                self._handle_message(msg)

            if not self.master.motors_armed():
                self.get_logger().warn('Pixhawk reports: DISARMED')
                return

        self.get_logger().warn('Disarm command was sent, but no explicit DISARMED confirmation was seen.')

    def send_override(self) -> None:
        # Keep throttle low unless a positive forward command is given
        if self.current_linear_x <= 0.0:
            throttle_pwm = self.idle_throttle
        else:
            throttle_span = self.max_throttle - self.spin_throttle_start
            throttle_pwm = int(
                self.spin_throttle_start + self.current_linear_x * throttle_span
            )

        yaw_delta = int(self.current_angular_z * self.max_yaw_delta)
        yaw_pwm = int(clamp(self.neutral_yaw + yaw_delta, 1100, 1900))

        self.master.mav.rc_channels_override_send(
            self.master.target_system,
            self.master.target_component,
            65535,        # ch1
            65535,        # ch2
            throttle_pwm, # ch3
            yaw_pwm,      # ch4
            65535,        # ch5
            65535,        # ch6
            65535,        # ch7
            65535         # ch8
        )

        if throttle_pwm != self.sent_throttle_pwm or yaw_pwm != self.sent_yaw_pwm:
            self.get_logger().info(
                f'Sent RC override: ch3={throttle_pwm}, ch4={yaw_pwm}, '
                f'linear_x={self.current_linear_x:.2f}, angular_z={self.current_angular_z:.2f}'
            )
            self.sent_throttle_pwm = throttle_pwm
            self.sent_yaw_pwm = yaw_pwm

    def poll_telemetry(self) -> None:
        while True:
            msg = self.master.recv_match(blocking=False)
            if msg is None:
                break
            self._handle_message(msg)

    def _handle_message(self, msg) -> None:
        msg_type = msg.get_type()

        if msg_type == 'HEARTBEAT':
            self._handle_heartbeat(msg)

        elif msg_type == 'STATUSTEXT':
            text = getattr(msg, 'text', '')
            if text:
                self.get_logger().warn(f'Pixhawk STATUSTEXT: {text}')

        elif msg_type == 'COMMAND_ACK':
            command = getattr(msg, 'command', None)
            result = getattr(msg, 'result', None)
            self.get_logger().info(f'COMMAND_ACK received: command={command}, result={result}')

        elif msg_type == 'RC_CHANNELS':
            self.get_logger().info(
                f'RC_CHANNELS seen: '
                f'ch1={getattr(msg, "chan1_raw", None)} '
                f'ch2={getattr(msg, "chan2_raw", None)} '
                f'ch3={getattr(msg, "chan3_raw", None)} '
                f'ch4={getattr(msg, "chan4_raw", None)}'
            )

        elif msg_type == 'SERVO_OUTPUT_RAW':
            self.get_logger().info(
                f'SERVO_OUTPUT_RAW seen: '
                f's1={getattr(msg, "servo1_raw", None)} '
                f's2={getattr(msg, "servo2_raw", None)} '
                f's3={getattr(msg, "servo3_raw", None)} '
                f's4={getattr(msg, "servo4_raw", None)}'
            )

    def _handle_heartbeat(self, msg) -> None:
        armed = bool(msg.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
        mode = mavutil.mode_string_v10(msg)

        if armed != self.last_armed_state:
            self.last_armed_state = armed
            self.get_logger().info(f'Pixhawk armed state changed: {"ARMED" if armed else "DISARMED"}')

        if mode != self.last_mode:
            self.last_mode = mode
            self.get_logger().info(f'Pixhawk mode: {mode}')

    def cleanup(self) -> None:
        if self.cleaned_up:
            return

        self.cleaned_up = True

        try:
            if self.disarm_on_shutdown and self.master.motors_armed():
                self.disarm_vehicle()
        except Exception:
            pass

    def destroy_node(self):
        self.cleanup()
        return super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = MavMotorController()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cleanup()
        try:
            node.destroy_node()
        except Exception:
            pass
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
